import { useState } from "react";

const RED = "#E63329";
const BLUE = "#1A6FBF";

const COMM_DATA = [
  { title: "Unit 1 — Mass Media Industries", note: null, cards: [
    ["Trade Books","Books sold to the general public — novels, self-help, cookbooks, etc."],
    ["Textbooks","Educational books made specifically for classroom use."],
    ["Professional / Scholarly Books","Written for experts and researchers in a specific field."],
    ["Yellow Journalism","Sensational, exaggerated news designed to shock and sell papers — not factual."],
    ["Tabloids","Small-format papers focused on gossip, scandal, and dramatic headlines."],
    ["Broadsheet","Large-format serious newspapers like the New York Times."],
    ["Consumer Magazines","Magazines for the general public — Vogue, Sports Illustrated, Time."],
    ["Trade / Technical Magazines","Magazines written for people working in a specific industry."],
    ["Muckrakers","Early investigative journalists who exposed corruption and social problems."],
    ["RIAA","Recording Industry Association of America — protects music copyright, certifies gold/platinum records."],
    ["File Sharing","Distributing digital files online — often illegally without paying creators."],
    ["DMCA","Digital Millennium Copyright Act — federal law protecting digital content from piracy online."],
    ["Podcast","On-demand audio show you subscribe to and stream — no broadcast schedule."],
    ["FM Radio","Clear sound, shorter range — local music and talk stations."],
    ["AM Radio","Travels farther but lower quality — used for talk radio and news."],
    ["Satellite Radio","Paid subscription radio like SiriusXM — works nationwide, no local signal needed."],
    ["Blacklisting","Banning someone from working in an industry — famous in 1950s Hollywood during the Red Scare."],
    ["Ancillary Rights","Extra income streams from a media property — merchandise, sequels, licensing, theme parks."],
    ["Network","A group of TV or radio stations that all broadcast the same content (NBC, CBS, Fox)."],
    ["Sweeps","Rating periods where networks air their best content to attract more advertisers."],
    ["Demographics","Statistics about an audience — age, gender, income, location, race."],
    ["Search Marketing","Paying to appear at the top of Google results when users search certain keywords."],
    ["Digital Divide","The gap between people who have reliable internet access and those who don't."],
  ]},
  { title: "Unit 2 — Marketing", note: null, cards: [
    ["Traditional Advertising","TV, radio, billboards, print — broad reach, harder to target or measure."],
    ["Digital Advertising","Social media ads, Google ads, email campaigns — targeted and trackable."],
    ["Ethos","Appeal to credibility and trust — 'doctors recommend this', celebrity endorsements."],
    ["Pathos","Appeal to emotion — makes you feel sad, excited, scared, or inspired to act."],
    ["Logos","Appeal to logic — uses facts, stats, and data to convince you rationally."],
    ["PSA","Public Service Announcement — non-profit ad for social good. No product being sold."],
    ["Billboard","Large outdoor advertising display on roadsides or buildings."],
    ["Brand","The overall identity of a company — its name, vibe, values, and reputation."],
    ["Logo","The visual symbol representing a brand — Nike swoosh, Apple logo, McDonald's arches."],
  ]},
  { title: "Unit 3 — Video Essays", note: { label: "FAIR USE", text: " — Protected when: (1) educational, commentary, parody, or news purpose · (2) limited amount used · (3) transformative — adds new meaning · (4) doesn't replace the original in the market. Example: 10 seconds of a song in a student review = likely Fair Use. Full song = not Fair Use.", color: BLUE }, cards: [
    ["Footage","Raw video clips used in a project before editing."],
    ["Tracks","Separate layers in a video editing timeline — video, voiceover, music."],
    ["Transitions","Visual effects between clips — cuts, fades, dissolves, wipes."],
    ["A Roll","Primary footage — main subject talking to camera or the key action happening."],
    ["B Roll","Supplemental footage playing while A Roll audio continues — cutaways, establishing shots."],
    ["Lower Thirds","Text overlay in the lower screen showing a person's name, title, or location."],
    ["Thumbnails","Preview image representing a video — determines whether people click it."],
    ["Fair Use","Legal right to use copyrighted material for education, commentary, parody, or news — must be transformative and not replace the original."],
  ]},
  { title: "Unit 4 — Film", note: null, cards: [
    ["Director","The creative lead of a film — makes all major artistic decisions."],
    ["Costume Design","Designing clothing that shows character personality, social status, and time period."],
    ["Score","Original instrumental music composed specifically for the film."],
    ["Soundtrack","Collection of songs used throughout a film — can include pre-existing popular music."],
    ["SFX","Sound Effects — added sounds like explosions, footsteps, door creaks."],
    ["Lighting","How light and shadow set mood, reveal or conceal characters, and create atmosphere."],
    ["Casting","The process of selecting actors for specific roles in a production."],
    ["Tone","The overall emotional feel or attitude of a film — dark, comedic, tense, hopeful."],
  ]},
  { title: "SPACECAT — Full Breakdown", note: null, cards: [
    ["S — Speaker","Who created this? What is their background, credibility, or bias?"],
    ["P — Purpose","Why did they make this? What are they trying to achieve or change?"],
    ["A — Audience","Who is this made for? What does the audience already believe going in?"],
    ["C — Context","What was happening in society or history when this was created?"],
    ["E — Exigence","What urgent problem or event caused this piece to be created right now?"],
    ["C — Claims","What is the author's main argument or central point?"],
    ["A — Appeals","How do they use Ethos (credibility), Pathos (emotion), Logos (logic)?"],
    ["T — Tone","What is the emotional attitude of the piece toward its subject?"],
  ]},
];

const CEA_DATA = [
  { title: "Careers & Organizations", note: null, cards: [
    ["Architect","A professional trained in the art and science of designing and constructing buildings."],
    ["Civil Engineer","An engineer trained to design and build public works — bridges, dams, roads, large infrastructure."],
    ["AIA","American Institute of Architects — the professional society representing architects in the US."],
    ["ASCE","American Society of Civil Engineers — the professional society for civil engineers."],
    ["NAAB","National Architectural Accrediting Board — the only agency that accredits architecture degree programs in the US."],
    ["ABET","Accredits college and university engineering programs to ensure quality standards."],
    ["NCARB","National Council of Architectural Registration Boards — made up of all 50 state licensing boards."],
    ["Building Codes","Legal safety requirements covering structural, electrical, plumbing, and mechanical standards."],
    ["Charrette","Intensive collaborative workshop where experts tackle a design problem together quickly."],
    ["Construction Documents","All drawings, plans, and specifications for a construction project."],
    ["Municipality","A city or town with its own incorporated local government."],
  ]},
  { title: "Design Principles & Elements", note: null, cards: [
    ["Aesthetics","The quality of an object relating to art, beauty, and taste."],
    ["Balance","Equal visual weight distributed on both sides of a composition."],
    ["Emphasis","Making one element stand out through contrast, size, or placement."],
    ["Rhythm","A sense of flow created by repeating design elements in a pattern."],
    ["Repetition","Using the same element multiple times throughout a design to create cohesion."],
    ["Movement","The illusion of motion or direction created by how elements relate to each other."],
    ["Pattern","A decorative design unit that repeats in a structured way."],
    ["Unity","All design elements working together as one coherent whole."],
    ["Color","Described by hue (the color), lightness (how light/dark), and saturation (how vivid)."],
    ["Form","The shape and structure of something, separate from its material."],
    ["Line","The edge or contour defining the boundary of a shape."],
    ["Element of Design","A basic visual building block — line, shape, form, space, texture, color, value."],
    ["Principles of Design","Rules for arranging design elements — balance, rhythm, emphasis, unity, variety."],
  ]},
  { title: "Structural Terms", note: null, cards: [
    ["Arch","Curved structure spanning an opening, supporting load through axial compression — no tension."],
    ["Keystone","Wedge-shaped stone at the crown (top) of an arch — locks the whole arch together."],
    ["Lintel","Horizontal beam placed over a door or window opening to carry the weight above."],
    ["Post-and-Lintel","Structural system using vertical posts and horizontal beams — the oldest construction method."],
    ["Facade","The exterior face of a building, especially the front visible from the street."],
    ["Floor Joists","Horizontal structural members carrying floor and ceiling load to the walls."],
    ["Header","Horizontal structural member at the top of a door or window opening that redirects load."],
    ["Bearing Walls","Solid walls that support each other and carry the roof load above."],
    ["Dead Load","Permanent constant weight a structure carries — walls, floors, roof materials."],
    ["Live Load","Temporary or variable weight — people, furniture, snow, wind pressure."],
  ]},
  { title: "Construction Materials", note: null, cards: [
    ["House Wrap","Engineered membrane that blocks liquid water but lets water vapor escape."],
    ["Felt","Tar-impregnated paper used as a moisture barrier under roofing shingles."],
  ]},
  { title: "Process & Documentation", note: null, cards: [
    ["Feasibility Study","Evaluation of all factors — cost, site, regulations — to determine if a project can realistically happen."],
    ["Portfolio (Architect)","Professional documentation including sketches, drawings, renderings, and past project history."],
    ["Floor Plan","Top-down architectural drawing showing room layout, walls, and dimensions."],
    ["Elevation","Flat straight-on exterior view of one building side — shows height and facade details."],
    ["Site Access","Entry and exit points connecting a building to the public roadway."],
    ["Concept Map","Diagram linking related ideas graphically to develop a fuller understanding of a topic."],
  ]},
];

function Card({ term, def, color }) {
  const [flipped, setFlipped] = useState(false);
  return (
    <div onClick={() => setFlipped(!flipped)} style={{
      background: flipped ? (color === RED ? "#200C0A" : "#0B1E35") : "#1A1A1A",
      border: `1px solid ${flipped ? color : "#2A2A2A"}`,
      borderRadius: 9, padding: 13, minHeight: 76,
      display: "flex", flexDirection: "column", justifyContent: "space-between",
      cursor: "pointer", WebkitTapHighlightColor: "transparent", userSelect: "none",
    }}>
      {flipped ? (
        <>
          <p style={{ fontSize: 12, color: "#F0ECE3", lineHeight: 1.5, margin: 0 }}>{def}</p>
          <p style={{ fontSize: 10, color: "rgba(255,255,255,.3)", textAlign: "right", marginTop: 6 }}>tap to flip back</p>
        </>
      ) : (
        <>
          <p style={{ fontSize: 13, fontWeight: 700, color: "#F0ECE3", lineHeight: 1.2, margin: 0 }}>{term}</p>
          <p style={{ fontSize: 10, color: "#444", textAlign: "right", marginTop: 6 }}>tap for def</p>
        </>
      )}
    </div>
  );
}

function Section({ section, color, search }) {
  const [open, setOpen] = useState(true);
  const q = search.toLowerCase().trim();
  const filtered = q ? section.cards.filter(([t,d]) => t.toLowerCase().includes(q) || d.toLowerCase().includes(q)) : section.cards;
  if (q && filtered.length === 0) return null;
  return (
    <div style={{ marginTop: 20 }}>
      <div onClick={() => setOpen(!open)} style={{
        display: "flex", justifyContent: "space-between", alignItems: "center",
        padding: "10px 14px", borderRadius: 7,
        background: color === RED ? "#1C0A09" : "#09152A",
        borderLeft: `4px solid ${color}`, cursor: "pointer", marginBottom: 10,
        WebkitTapHighlightColor: "transparent", userSelect: "none",
      }}>
        <span style={{ fontSize: 13, fontWeight: 700, textTransform: "uppercase", letterSpacing: .5, color: "#F0ECE3" }}>{section.title}</span>
        <span style={{ fontSize: 11, color: "#555" }}>{section.cards.length} terms {open ? "▾" : "▸"}</span>
      </div>
      {open && (
        <>
          {section.note && (
            <div style={{ background: "#161616", border: "1px solid #2A2A2A", borderRadius: 8, padding: "13px 15px", marginBottom: 10, fontSize: 12, color: "#888", lineHeight: 1.7 }}>
              <span style={{ color: section.note.color, fontWeight: 700 }}>{section.note.label}</span>{section.note.text}
            </div>
          )}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {filtered.map(([t,d], i) => <Card key={i} term={t} def={d} color={color} />)}
          </div>
        </>
      )}
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("comm");
  const [search, setSearch] = useState("");
  const data = tab === "comm" ? COMM_DATA : CEA_DATA;
  const color = tab === "comm" ? RED : BLUE;

  return (
    <div style={{ background: "#0A0A0A", minHeight: "100vh", color: "#F0ECE3", fontFamily: "Arial, Helvetica, sans-serif", paddingBottom: 60 }}>
      <div style={{ padding: "28px 16px 0", maxWidth: 900, margin: "0 auto" }}>
        <p style={{ fontSize: 10, letterSpacing: 3, color: "#555", textTransform: "uppercase", marginBottom: 6 }}>June 2026 · Final Exams</p>
        <h1 style={{ fontSize: 38, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, lineHeight: 1, margin: 0 }}>
          Study <span style={{ color: RED }}>Guide</span>
        </h1>
        <p style={{ marginTop: 6, fontSize: 12, color: "#555" }}>Tap any card to flip · tap again to go back</p>
      </div>

      <div style={{ maxWidth: 900, margin: "20px auto 0", padding: "0 16px", display: "flex", gap: 8 }}>
        {[["comm","Comm Media",RED],["cea","PLTW CEA",BLUE]].map(([key,label,c]) => (
          <button key={key} onClick={() => { setTab(key); setSearch(""); }} style={{
            fontSize: 13, fontWeight: 700, textTransform: "uppercase", padding: "11px 20px",
            borderRadius: 6, border: "none", cursor: "pointer", fontFamily: "inherit",
            background: tab === key ? c : "#1A1A1A", color: tab === key ? "#fff" : "#555",
          }}>{label}</button>
        ))}
      </div>

      <div style={{ maxWidth: 900, margin: "16px auto 0", padding: "0 16px" }}>
        <input type="text" placeholder="Search terms..." value={search} onChange={e => setSearch(e.target.value)}
          style={{ width: "100%", background: "#1A1A1A", border: "1px solid #2A2A2A", borderRadius: 8, padding: "11px 14px", fontSize: 14, color: "#F0ECE3", fontFamily: "inherit", outline: "none" }}
        />
      </div>

      {tab === "comm" && (
        <div style={{ maxWidth: 900, margin: "20px auto 0", padding: "0 16px" }}>
          <div style={{ background: "#161616", border: "1px solid #2A2A2A", borderRadius: 8, padding: "13px 15px", fontSize: 12, color: "#888", lineHeight: 1.7 }}>
            <span style={{ color: RED, fontWeight: 700 }}>SPACECAT</span> — your in-class analysis framework:{" "}
            {[["S","peaker"],["P","urpose"],["A","udience"],["C","ontext"],["E","xigence"],["C","laims"],["A","ppeals (Ethos/Pathos/Logos)"],["T","one"]].map(([l,r],i,a) => (
              <span key={i}><span style={{ color: RED, fontWeight: 700 }}>{l}</span>{r}{i < a.length-1 ? " · " : ""}</span>
            ))}
          </div>
        </div>
      )}

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "0 16px" }}>
        {data.map((sec, i) => <Section key={tab+i} section={sec} color={color} search={search} />)}
      </div>

      <p style={{ textAlign: "center", fontSize: 11, color: "#2A2A2A", marginTop: 36 }}>56 total terms</p>
    </div>
  );
}
